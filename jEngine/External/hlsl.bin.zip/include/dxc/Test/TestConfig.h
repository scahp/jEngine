#define DEFAULT_TEST_DIR L"C:/Github/jEngine/jEngine/External/DirectXShaderCompiler/tools/clang/test/HLSL/"
#define DEFAULT_EXEC_TEST_DIR L"C:/Github/jEngine/jEngine/External/DirectXShaderCompiler/tools/clang/unittests/HLSLExec/"
