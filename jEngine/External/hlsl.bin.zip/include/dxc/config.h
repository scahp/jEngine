/* Disable overriding memory allocators. */
/* #undef DXC_DISABLE_ALLOCATOR_OVERRIDES */
