﻿#include "pch.h"
#include "jUtil.h"


jUtil::jUtil()
{
}


jUtil::~jUtil()
{
}
