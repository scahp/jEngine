﻿#include "pch.h"
#include "jRHI_DirectX11.h"


jRHI_DirectX11::jRHI_DirectX11()
{
}


jRHI_DirectX11::~jRHI_DirectX11()
{
}
