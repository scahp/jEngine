﻿#include "pch.h"
#include "TGALoader.h"


TGALoader::TGALoader()
{
}


TGALoader::~TGALoader()
{
}
