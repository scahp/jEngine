﻿#include "pch.h"
#include "jRHI_Vulkan.h"


jRHI_Vulkan::jRHI_Vulkan()
{
}


jRHI_Vulkan::~jRHI_Vulkan()
{
}
