﻿#pragma once
class TGALoader
{
public:
	TGALoader();
	~TGALoader();
};

