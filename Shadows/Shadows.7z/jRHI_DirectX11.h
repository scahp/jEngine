﻿#pragma once

#include "jRHI.h"

// todo 
class jRHI_DirectX11 : public jRHI
{
public:
	jRHI_DirectX11();
	~jRHI_DirectX11();
};

