﻿#pragma once
class jUtil
{
public:
	jUtil();
	~jUtil();
};

