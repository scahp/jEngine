﻿#include "pch.h"
#include "jDeferredRenderer.h"
#include "jObject.h"
#include "jShadowAppProperties.h"
#include "jRenderTargetPool.h"

#include "jRHI_OpenGL.h"		// todo it should be removed.
#include "jCamera.h"
#include "jLight.h"

//////////////////////////////////////////////////////////////////////////
// jDeferredRenderer
jDeferredRenderer::jDeferredRenderer(const jRenderTargetInfo& geometryBufferInfo)
{
	GeometryBufferInfo = geometryBufferInfo;
}

jDeferredRenderer::~jDeferredRenderer()
{
}

void jDeferredRenderer::Setup()
{
	GBuffer.GeometryBuffer = jRenderTargetPool::GetRenderTarget(GeometryBufferInfo);

	DeferredDeepShadowMapPipelineSet = new jDeferredDeepShadowMapPipelineSet(&GBuffer);
	DeferredDeepShadowMapPipelineSet->Setup();

	SetChangePipelineSet(DeferredDeepShadowMapPipelineSet);

	////////////////////////////////////////////////////////////////////////////
	//// Setup a postprocess chain
	OutRenderTarget = std::shared_ptr<jRenderTarget>(jRenderTargetPool::GetRenderTarget({ ETextureType::TEXTURE_2D, EFormat::RGBA, EFormat::RGBA, EFormatType::FLOAT, EDepthBufferType::DEPTH, SCR_WIDTH, SCR_HEIGHT, 1 }));
	PostProcessOutput = std::shared_ptr<jPostProcessInOutput>(new jPostProcessInOutput());
	PostProcessOutput->RenderTarget = OutRenderTarget.get();
	{
		// this postprocess have to have DeepShadowMap PipelineSet.
		JASSERT(PipelineSet->GetType() == EPipelineSetType::DeepShadowMap);
		auto deferredDeepShadowMapPipelineSet = static_cast<jDeferredDeepShadowMapPipelineSet*>(PipelineSet);
		auto& DeepShadowMapBuffers = deferredDeepShadowMapPipelineSet->DeepShadowMapBuffers;

		// LightPass of DeepShadowMap
		auto postprocess = new jPostProcess_DeepShadowMap("DeepShadow", { DeepShadowMapBuffers.StartElementBuf, DeepShadowMapBuffers.LinkedListEntryDepthAlphaNext, DeepShadowMapBuffers.LinkedListEntryNeighbors }, &GBuffer);
		postprocess->SetOutput(PostProcessOutput);
		PostProcessChain.AddNewPostprocess(postprocess);
	}

	{
		PostPrceoss_AA_DeepShadowAddition = std::shared_ptr<jRenderTarget>(jRenderTargetPool::GetRenderTarget({ ETextureType::TEXTURE_2D, EFormat::RGBA, EFormat::RGBA, EFormatType::FLOAT, EDepthBufferType::DEPTH, SCR_WIDTH, SCR_HEIGHT, 1 }));
		PostProcessOutput2 = std::shared_ptr<jPostProcessInOutput>(new jPostProcessInOutput());
		PostProcessOutput2->RenderTarget = PostPrceoss_AA_DeepShadowAddition.get();

		auto postprocess = new jPostProcess_AA_DeepShadowAddition("AA_DeepShadowAddition");
		postprocess->AddInput(PostProcessOutput);
		postprocess->SetOutput(PostProcessOutput2);
		PostProcessChain.AddNewPostprocess(postprocess);
	}

	{
		LuminanceRenderTarget = std::shared_ptr<jRenderTarget>(jRenderTargetPool::GetRenderTarget({ ETextureType::TEXTURE_2D, EFormat::R32F, EFormat::R, EFormatType::FLOAT, EDepthBufferType::DEPTH, LUMINANCE_WIDTH, LUMINANCE_HEIGHT, 1 }));
		PostProcessLuminanceOutput = std::shared_ptr<jPostProcessInOutput>(new jPostProcessInOutput());
		PostProcessLuminanceOutput->RenderTarget = LuminanceRenderTarget.get();

		auto postprocess = new jPostProcess_LuminanceMapGeneration("LuminanceMapGeneration");
		postprocess->AddInput(PostProcessOutput2);
		postprocess->SetOutput(PostProcessLuminanceOutput);
		PostProcessChain.AddNewPostprocess(postprocess);
	}

	auto avgLuminancePostProcessOutput = std::shared_ptr<jPostProcessInOutput>(new jPostProcessInOutput());
	{
		auto postprocess = new jPostProcess_AdaptiveLuminance("AdaptiveLuminance");
		postprocess->AddInput(PostProcessLuminanceOutput);
		postprocess->SetOutput(avgLuminancePostProcessOutput);
		PostProcessChain.AddNewPostprocess(postprocess);
	}

	{
		auto postprocess = new jPostProcess_Tonemap("Tonemap");
		postprocess->AddInput(PostProcessOutput2);
		postprocess->AddInput(avgLuminancePostProcessOutput);
		postprocess->SetOutput(nullptr);
		PostProcessChain.AddNewPostprocess(postprocess);
	}
}

void jDeferredRenderer::Teardown()
{
	
}

void jDeferredRenderer::ShadowPrePass(const jCamera* camera)
{
	SCOPE_DEBUG_EVENT(g_rhi, "ShadowPrePass");

	const auto directionalLight = camera->GetLight(ELightType::DIRECTIONAL);
	std::list<const jLight*> lights;
	if (directionalLight)
		lights.push_back(directionalLight);

	// todo Directional Light 만 쓸건가?
	const jPipelineData data(nullptr, jObject::GetShadowCasterObject(), camera, lights);

	for (auto& iter : PipelineSet->ShadowPrePass)
		iter->Do(data);
}

void jDeferredRenderer::RenderPass(const jCamera* camera)
{
	SCOPE_DEBUG_EVENT(g_rhi, "RenderPass");

	const auto directionalLight = camera->GetLight(ELightType::DIRECTIONAL);

	std::list<const jLight*> lights;
	if (directionalLight)
		lights.push_back(directionalLight);

	// Geometry Pass
	// todo Directional Light 만 쓸건가?
	const jPipelineData data(nullptr, jObject::GetStaticObject(), camera, lights);

	for (auto& iter : PipelineSet->RenderPass)
		iter->Do(data);
}

void jDeferredRenderer::DebugRenderPass(const jCamera* camera)
{
	SCOPE_DEBUG_EVENT(g_rhi, "DebugRenderPass");

	if (GBuffer.Begin())
	{
		const jPipelineData data(nullptr, jObject::GetDebugObject(), camera, {});
		for (auto& iter : PipelineSet->DebugRenderPass)
			iter->Do(data);
		GBuffer.End();
	}
}

void jDeferredRenderer::BoundVolumeRenderPass(const jCamera* camera)
{
	SCOPE_DEBUG_EVENT(g_rhi, "BoundVolumeRenderPass");

	if (GBuffer.Begin())
	{
		if (jShadowAppSettingProperties::GetInstance().ShowBoundBox)
		{
			const jPipelineData data(nullptr, jObject::GetBoundBoxObject(), camera, {});
			for (auto& iter : PipelineSet->BoundVolumeRenderPass)
				iter->Do(data);
		}

		if (jShadowAppSettingProperties::GetInstance().ShowBoundSphere)
		{
			const jPipelineData data(nullptr, jObject::GetBoundSphereObject(), camera, {});
			for (auto& iter : PipelineSet->BoundVolumeRenderPass)
				iter->Do(data);
		}
		GBuffer.End();
	}
}

void jDeferredRenderer::PostProcessPass(const jCamera* camera)
{
	SCOPE_DEBUG_EVENT(g_rhi, "PostProcessPass");
	PostProcessChain.Process(camera);
}

void jDeferredRenderer::PostRenderPass(const jCamera* camera)
{
	SCOPE_DEBUG_EVENT(g_rhi, "PostRenderPass");
	for (auto& iter : PipelineSet->PostRenderPass)
		iter->Do({});
}
