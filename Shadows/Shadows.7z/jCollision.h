﻿#pragma once
class jCollision
{
public:
	jCollision();
	~jCollision();
};

