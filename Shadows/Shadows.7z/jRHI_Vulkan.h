﻿#pragma once

#include "jRHI.h"

// todo
class jRHI_Vulkan : public jRHI
{
public:
	jRHI_Vulkan();
	~jRHI_Vulkan();
};

