﻿#include "pch.h"
#include "jInputEvent.h"


jInputEvent::jInputEvent()
{
}


jInputEvent::~jInputEvent()
{
}
