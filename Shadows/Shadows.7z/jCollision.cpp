﻿#include "pch.h"
#include "jCollision.h"


jCollision::jCollision()
{
}


jCollision::~jCollision()
{
}
