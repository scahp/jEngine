﻿#pragma once
class jInputEvent
{
public:
	jInputEvent();
	~jInputEvent();
};

